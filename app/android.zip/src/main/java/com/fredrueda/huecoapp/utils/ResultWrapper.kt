package com.fredrueda.huecoapp.utils

class ResultWrapper {
}