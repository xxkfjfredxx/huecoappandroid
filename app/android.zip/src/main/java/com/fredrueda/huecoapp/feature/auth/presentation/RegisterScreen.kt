package com.fredrueda.huecoapp.feature.auth.presentation

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController

@Composable
fun RegisterScreen(navController: NavController, vm: AuthViewModel = hiltViewModel()) {
    val state = vm.registerState

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    TopAppBar(
        title = {},
        navigationIcon = {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Volver"
                )
            }
        }
    )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 40.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Crear cuenta", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(24.dp))

        // Inputs
        ModernInput(value = email, label = "Correo", keyboardType = KeyboardType.Email) {
            email = it
        }
        ModernInput(value = password, label = "Contraseña", isPassword = true) {
            password = it
        }
        ModernInput(value = username, label = "Nombre de usuario") {
            username = it
        }
        ModernInput(value = firstName, label = "Nombre") {
            firstName = it
        }
        ModernInput(value = lastName, label = "Apellido") {
            lastName = it
        }

        Spacer(Modifier.height(28.dp))

        ModernButton(
            text = "Registrarme",
            loading = state.isLoading,
            onClick = {
                vm.register(email, password, username, firstName, lastName)
            }
        )

        if (state.isSuccess) {
            Spacer(Modifier.height(16.dp))
            Text(text = state.message ?: "Código enviado", color = MaterialTheme.colorScheme.primary)

            LaunchedEffect(true) {
                navController.navigate("verify_register?email=$email")
            }
        }
    }
}

@Composable
fun VerifyRegisterScreen(navController: NavController, email: String, vm: AuthViewModel = hiltViewModel()) {
    val state = vm.verifyRegisterState
    val authState = vm.state.collectAsState().value

    var code by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
            .padding(top = 40.dp),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Verificar correo", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(24.dp))

        ModernInput(
            value = code,
            label = "Código de verificación",
            keyboardType = KeyboardType.Number
        ) { code = it }

        Spacer(Modifier.height(28.dp))

        ModernButton(
            text = "Verificar",
            loading = state.isLoading,
            onClick = {
                vm.verifyRegister(email, code)
            }
        )

        state.error?.let {
            Spacer(Modifier.height(16.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }

        if (state.isVerified && authState.user != null) {
            LaunchedEffect(true) {
                navController.navigate("home") {
                    popUpTo(0)
                }
            }
        }
    }
}

// -----------------------------
// COMPONENTES MODERNOS
// -----------------------------

@Composable
fun ModernInput(
    value: String,
    label: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    isPassword: Boolean = false,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        visualTransformation = if (isPassword) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        shape = MaterialTheme.shapes.medium
    )
    Spacer(Modifier.height(12.dp))
}

@Composable
fun ModernButton(text: String, loading: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = MaterialTheme.shapes.medium,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(0xFF007AFF),
            contentColor = Color.White
        )
    ) {
        if (loading) {
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 2.dp
            )
        } else {
            Text(text, style = MaterialTheme.typography.titleMedium)
        }
    }
}