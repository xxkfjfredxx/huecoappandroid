package com.fredrueda.huecoapp.ui.components

class AppBar {
}