package com.fredrueda.huecoapp.utils.extensions

class StringExt {
}